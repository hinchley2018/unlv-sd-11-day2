--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1 (Debian 16.1-1.pgdg120+1)
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE rental_movies;
--
-- Name: rental_movies; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE rental_movies WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE rental_movies OWNER TO root;

\connect rental_movies

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: movies; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.movies (
    movie_id integer NOT NULL,
    title character varying(255) NOT NULL,
    release_year integer,
    genre character varying(255),
    rental_price numeric(10,2),
    available boolean DEFAULT true,
    length_in_minutes integer,
    replacement_cost integer,
    rating character varying(10)
);


ALTER TABLE public.movies OWNER TO root;

--
-- Name: movies_movie_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.movies_movie_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.movies_movie_id_seq OWNER TO root;

--
-- Name: movies_movie_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.movies_movie_id_seq OWNED BY public.movies.movie_id;


--
-- Name: rentals; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.rentals (
    rental_id integer NOT NULL,
    movie_id integer,
    rental_duration integer,
    customer_name character varying(255),
    customer_email character varying(255)
);


ALTER TABLE public.rentals OWNER TO root;

--
-- Name: rentals_rental_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

CREATE SEQUENCE public.rentals_rental_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rentals_rental_id_seq OWNER TO root;

--
-- Name: rentals_rental_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: root
--

ALTER SEQUENCE public.rentals_rental_id_seq OWNED BY public.rentals.rental_id;


--
-- Name: movies movie_id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.movies ALTER COLUMN movie_id SET DEFAULT nextval('public.movies_movie_id_seq'::regclass);


--
-- Name: rentals rental_id; Type: DEFAULT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.rentals ALTER COLUMN rental_id SET DEFAULT nextval('public.rentals_rental_id_seq'::regclass);


--
-- Data for Name: movies; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.movies (movie_id, title, release_year, genre, rental_price, available, length_in_minutes, replacement_cost, rating) FROM stdin;
\.
COPY public.movies (movie_id, title, release_year, genre, rental_price, available, length_in_minutes, replacement_cost, rating) FROM '$$PATH$$/3360.dat';

--
-- Data for Name: rentals; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.rentals (rental_id, movie_id, rental_duration, customer_name, customer_email) FROM stdin;
\.
COPY public.rentals (rental_id, movie_id, rental_duration, customer_name, customer_email) FROM '$$PATH$$/3362.dat';

--
-- Name: movies_movie_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.movies_movie_id_seq', 1, false);


--
-- Name: rentals_rental_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.rentals_rental_id_seq', 39, true);


--
-- Name: movies movies_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.movies
    ADD CONSTRAINT movies_pkey PRIMARY KEY (movie_id);


--
-- Name: rentals rentals_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.rentals
    ADD CONSTRAINT rentals_pkey PRIMARY KEY (rental_id);


--
-- Name: rentals rentals_movie_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.rentals
    ADD CONSTRAINT rentals_movie_id_fkey FOREIGN KEY (movie_id) REFERENCES public.movies(movie_id);


--
-- PostgreSQL database dump complete
--

